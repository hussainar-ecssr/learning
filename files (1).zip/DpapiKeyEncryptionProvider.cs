using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using Hili.Crypto.Primitives;

namespace Hili.Crypto.Keys
{
    /// <summary>
    /// Interim KEK storage for servers without an HSM.
    ///
    /// The 32-byte KEK is stored in a file encrypted with Windows DPAPI (LocalMachine scope + label-bound entropy):
    ///   - the file cannot be decrypted on any other machine (copying it off the server is useless);
    ///   - on this machine, the NTFS ACL is the real protection: only SYSTEM, Administrators and the
    ///     configured reader accounts (IIS app pool, migrator account) may read it.
    ///
    /// Unlike an HSM the KEK is loaded into process memory while keys are unwrapped at startup
    /// (then zeroed on Dispose). Switch to the Pkcs11 provider with "Hili.Migrator rewrap-keys" once an HSM is available.
    ///
    /// File format: "HKEK" | version(1) | DPAPI blob.
    /// </summary>
    public sealed class DpapiKeyEncryptionProvider : IKeyEncryptionProvider
    {
        private static readonly byte[] Magic = { (byte)'H', (byte)'K', (byte)'E', (byte)'K' };
        private const byte FileVersion = 1;
        private const string BackupHeader = "HILI KEK BACKUP v1";

        private byte[] _kek;
        public string KekLabel { get; }
        public string KekFilePath { get; }

        public DpapiKeyEncryptionProvider(string kekFilePath, string label)
        {
            if (string.IsNullOrWhiteSpace(kekFilePath)) throw new InvalidOperationException("Crypto:DpapiKekFile is not configured.");
            if (string.IsNullOrWhiteSpace(label)) throw new InvalidOperationException("Crypto:KekLabel is not configured.");
            KekFilePath = kekFilePath;
            KekLabel = label;
        }

        public bool KekFileExists => File.Exists(KekFilePath);

        private byte[] Kek
        {
            get
            {
                if (_kek != null) return _kek;
                if (!File.Exists(KekFilePath))
                    throw new InvalidOperationException($"KEK file '{KekFilePath}' not found. Run: Hili.Migrator init-kek --backup <path>  (or import-kek on additional servers).");
                _kek = ReadKekFile(KekFilePath, KekLabel);
                return _kek;
            }
        }

        public byte[] WrapKey(byte[] plainKey) => KeyWrap.Wrap(Kek, plainKey);
        public byte[] UnwrapKey(byte[] wrappedKey) => KeyWrap.Unwrap(Kek, wrappedKey);

        public void Dispose()
        {
            if (_kek != null) { CryptoUtil.Zero(_kek); _kek = null; }
        }

        // ---------------------------------------------------------------- file I/O

        private static byte[] Entropy(string label) => Encoding.UTF8.GetBytes("HILI-KEK-FILE-v1|" + label);

        private static byte[] ReadKekFile(string path, string label)
        {
            byte[] file = File.ReadAllBytes(path);
            if (file.Length < 6 || !CryptoUtil.FixedTimeEquals(file, 0, Magic, 0, 4) || file[4] != FileVersion)
                throw new CryptographicException($"'{path}' is not a Hili KEK file.");

            byte[] kek;
            try
            {
                kek = ProtectedData.Unprotect(CryptoUtil.Slice(file, 5, file.Length - 5), Entropy(label), DataProtectionScope.LocalMachine);
            }
            catch (CryptographicException ex)
            {
                throw new CryptographicException(
                    "Cannot decrypt the KEK file. Either Crypto:KekLabel differs from the label it was created with, " +
                    "or the file was copied from another machine (use import-kek with the offline backup instead).", ex);
            }
            if (kek.Length != 32) { CryptoUtil.Zero(kek); throw new CryptographicException("KEK file does not contain a 32-byte key."); }
            return kek;
        }

        /// <summary>
        /// Writes the DPAPI-protected KEK file with a locked-down ACL. Refuses to overwrite an existing file.
        /// readers: accounts allowed to read, e.g. "IIS AppPool\HiliApi", "DOMAIN\svc-hili-migrator".
        /// </summary>
        public static void WriteKekFile(string path, string label, byte[] kek, IEnumerable<string> readers)
        {
            if (kek == null || kek.Length != 32) throw new ArgumentException("KEK must be 32 bytes.");
            if (File.Exists(path)) throw new InvalidOperationException($"'{path}' already exists. Refusing to overwrite a KEK.");

            string dir = Path.GetDirectoryName(Path.GetFullPath(path));
            var security = BuildAcl(readers);
            if (!Directory.Exists(dir))
            {
                var ds = new DirectorySecurity();
                ds.SetSecurityDescriptorSddlForm(security.GetSecurityDescriptorSddlForm(AccessControlSections.Access));
                Directory.CreateDirectory(dir, ds);
            }

            byte[] blob = ProtectedData.Protect(kek, Entropy(label), DataProtectionScope.LocalMachine);
            byte[] content = new byte[5 + blob.Length];
            Buffer.BlockCopy(Magic, 0, content, 0, 4);
            content[4] = FileVersion;
            Buffer.BlockCopy(blob, 0, content, 5, blob.Length);

            // Create with the ACL already applied (no window where the file has inherited permissions).
            using (var fs = new FileStream(path, FileMode.CreateNew, FileSystemRights.Write, FileShare.None, 4096, FileOptions.WriteThrough, security))
                fs.Write(content, 0, content.Length);

            // Self-check: read back and compare.
            var check = ReadKekFile(path, label);
            bool ok = CryptoUtil.FixedTimeEquals(check, kek);
            CryptoUtil.Zero(check);
            if (!ok) { File.Delete(path); throw new CryptographicException("KEK file verification failed."); }
        }

        private static FileSecurity BuildAcl(IEnumerable<string> readers)
        {
            var fsec = new FileSecurity();
            fsec.SetAccessRuleProtection(true, false); // no inheritance from the parent folder
            fsec.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl, AccessControlType.Allow));
            fsec.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), FileSystemRights.FullControl, AccessControlType.Allow));
            foreach (var r in readers ?? new string[0])
            {
                if (string.IsNullOrWhiteSpace(r)) continue;
                // NTAccount -> SID translation fails early if the account (e.g. the app pool) doesn't exist yet.
                var sid = (SecurityIdentifier)new NTAccount(r.Trim()).Translate(typeof(SecurityIdentifier));
                fsec.AddAccessRule(new FileSystemAccessRule(sid, FileSystemRights.Read | FileSystemRights.Synchronize, AccessControlType.Allow));
            }
            return fsec;
        }

        // ---------------------------------------------------------------- offline backup

        /// <summary>Fingerprint of the KEK, printed in the backup and in logs. Reveals nothing about the key.</summary>
        public static string Fingerprint(byte[] kek)
        {
            using (var h = new HMACSHA256(kek))
                return CryptoUtil.ToHex(CryptoUtil.Slice(h.ComputeHash(Encoding.UTF8.GetBytes("HILI-KEK-FP-v1")), 0, 8));
        }

        /// <summary>
        /// Writes the plaintext KEK backup. This file IS the master key: write it straight to removable media,
        /// store offline (safe / escrow), never on the server, a share, or in source control.
        /// </summary>
        public static void WriteBackup(string path, string label, byte[] kek)
        {
            if (File.Exists(path)) throw new InvalidOperationException($"'{path}' already exists.");
            var sb = new StringBuilder();
            sb.AppendLine(BackupHeader);
            sb.AppendLine("label: " + label);
            sb.AppendLine("created-utc: " + DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture));
            sb.AppendLine("fingerprint: " + Fingerprint(kek));
            sb.AppendLine("key: " + Convert.ToBase64String(kek));
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
        }

        public static byte[] ReadBackup(string path, out string label)
        {
            label = null;
            string fp = null, key = null;
            var lines = File.ReadAllLines(path);
            if (lines.Length == 0 || lines[0].Trim() != BackupHeader) throw new InvalidDataException("Not a Hili KEK backup file.");
            foreach (var line in lines)
            {
                int i = line.IndexOf(':');
                if (i <= 0) continue;
                string k = line.Substring(0, i).Trim(), v = line.Substring(i + 1).Trim();
                if (k == "label") label = v;
                else if (k == "fingerprint") fp = v;
                else if (k == "key") key = v;
            }
            if (label == null || fp == null || key == null) throw new InvalidDataException("KEK backup is incomplete.");
            var kek = Convert.FromBase64String(key);
            if (kek.Length != 32 || !string.Equals(Fingerprint(kek), fp, StringComparison.OrdinalIgnoreCase))
            {
                CryptoUtil.Zero(kek);
                throw new InvalidDataException("KEK backup is corrupt (fingerprint mismatch).");
            }
            return kek;
        }
    }
}
