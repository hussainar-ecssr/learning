# HSM + AES Encryption for MSSQL Columns & Documents (.NET Framework 4.7.2)

Application-level envelope encryption with an HSM-held master key, searchable encrypted
columns, encrypted file storage with decrypt-on-view, and a resumable migrator for existing data.

## Architecture

```
            ┌──────────── HSM (PKCS#11) ────────────┐
            │  KEK  AES-256, non-extractable         │   called only at startup / key creation
            └───────────────┬───────────────────────┘
                 wrap/unwrap│
      dbo.EncKeyRing ───────┴─────────────────────────────
        DATA  key(s)  ── HKDF ──► field enc/mac keys ──► *_Enc columns (AES-256-CBC + HMAC-SHA256)
                      └─ HKDF(salt per file) ──────────► *.henc files
        INDEX key     ── HKDF per table.column ────────► *_BIdx (exact)  +  dbo.EncSearchToken (contains)
```

| Piece | What it does |
|---|---|
| `Hili.Crypto` | Shared library: HSM providers, key ring, `FieldCipher`, `BlindIndexer`, `FileCipher`, repository helpers |
| `Hili.Api` | Web API 2 controllers + repositories for `Members` and `Documents` (the pattern for any table) |
| `Hili.Migrator` | Console tool: HSM KEK setup, key creation, encrypt/verify existing columns and files |
| `sql/` | 01 crypto tables · 02 add encrypted columns + triggers · 03 cutover (drop plaintext) |
| `encryption-map.json` | Which table/columns are encrypted and how each is searchable |

### Why AES-CBC + HMAC and not AES-GCM
.NET Framework 4.7.2 has no `AesGcm` class. Encrypt-then-MAC (AES-256-CBC + HMAC-SHA256 with
separate HKDF-derived keys, constant-time tag comparison) gives equivalent authenticated encryption.
Every column ciphertext is bound to its `schema.table.column`, so a value copied into another column
fails to decrypt. Every blob carries a key id, so key rotation doesn't require re-encrypting old data.

## Search & filtering on encrypted text

| Mode | Storage | Query | Use for |
|---|---|---|---|
| `Exact` | `Col_BIdx BINARY(32)` = HMAC(normalized value), indexed | `WHERE Email_BIdx = @hmac` | email, national ID, status codes, uniqueness checks, dropdown filters |
| `Contains` | HMAC'd trigrams in `dbo.EncSearchToken` + `_BIdx` | tokens of the search term, rows matching all tokens, then decrypt-and-verify | names, titles, file names, phone fragments |
| `None` | `Col_Enc` only | — | addresses, notes |

Normalizers (`Text`, `Exact`, `Digits`) make search case/diacritic-insensitive and unify Arabic
variants (أ إ آ → ا, ة → ه, ى → ي, tashkeel/tatweel removed, Arabic-Indic digits → 0-9).

**Limitations to design around:**
- No range queries, `ORDER BY` or `LIKE` on encrypted columns. Keep columns you sort/range-filter on
  (dates, amounts, status) unencrypted, or sort the decrypted page in memory.
- Search terms of 1–2 characters match whole words only.
- `Total` in search results is the candidate count; the few trigram false positives are removed after decryption.
- Blind indexes are deterministic: someone with DB access can see *which rows share a value* (not the value).
  Per-column keys and 16-byte truncated tokens limit this; restrict DB access accordingly.
- Changing a normalizer or rotating the INDEX key requires recomputing all `_BIdx` + tokens
  (a re-index command is not included; it is `encrypt-columns` logic reading from `_Enc` instead of plaintext).

## Documents
- Upload: buffered in memory (bounded by `maxRequestLength`), encrypted straight to `yyyy\MM\{guid}.henc`.
  Plaintext and the original file name never touch the disk.
- View/download: `GET api/documents/{id}/content[?download=true]`. The whole file's HMAC is verified
  **before** the first byte is streamed, from the same locked file handle. Responses are `no-store`,
  `nosniff`, and HTML/SVG/XML are always forced to download.
- No HTTP range requests (video seeking) with this format.

## Setup

1. **NuGet** — `Hili.Crypto`: Pkcs11Interop 5.1.2, Dapper 2.1.x, Newtonsoft.Json 13.
   `Hili.Api`: create *ASP.NET Web Application (.NET Framework 4.7.2) → Web API*, reference `Hili.Crypto`,
   add `Microsoft.AspNet.WebApi` 5.2.9, copy in the `src/Hili.Api` files, merge `Web.config.sample.xml`,
   put `encryption-map.json` in `App_Data`.
2. **KEK storage** — choose `Crypto:Provider`:
   - `Dpapi` — **no HSM yet.** See "Running without an HSM" below.
   - `Pkcs11` — HSM, as follows.

   **HSM** — create a partition/token and a crypto-user PIN. Set the PIN as an environment variable
   (`HILI_HSM_PIN`) for the IIS app pool identity and the migrator account; never in config files.
   IIS app pool must be 64-bit to match the vendor PKCS#11 DLL.
   *Dev:* install SoftHSM2 for Windows, then `softhsm2-util --init-token --free --label HILI-DEV --pin 1234 --so-pin 5678`.
3. **Database** — run `sql/01_create_crypto_objects.sql`.
4. **Keys**
   ```
   Hili.Migrator init-kek
   Hili.Migrator create-key DATA
   Hili.Migrator create-key INDEX
   ```
   Back up the HSM partition (vendor backup/cloning) **before** encrypting anything.
   Losing the KEK = losing all data. Test a restore.

## Running without an HSM (Dpapi provider) and switching later

Until the HSM arrives, the KEK lives in a file on the server encrypted with Windows DPAPI
(LocalMachine scope, entropy bound to the KEK label) and locked down with an NTFS ACL
(SYSTEM, Administrators, and the accounts in `Crypto:DpapiKekReaders` only).
Everything else — DATA/INDEX keys in `dbo.EncKeyRing`, column/file formats, search — is identical to the HSM setup.

**What it protects against:** stolen DB backups, DBAs, copies of the file share, and copying the KEK file to
another machine (DPAPI won't decrypt it there). **What it doesn't:** an administrator or malware running on
the web server can read the KEK. That residual risk is what the HSM removes.

**Setup (on the first server, as an administrator):**
1. Create the app pool (e.g. `HiliApi`) first so its identity can be put on the ACL.
2. Set `Crypto:Provider=Dpapi`, `Crypto:DpapiKekFile`, `Crypto:DpapiKekReaders` in `App.config` and `Web.config`.
3. With a USB drive / encrypted removable media plugged in:
   ```
   Hili.Migrator init-kek --backup F:\HILI-KEK-01.backup.txt
   Hili.Migrator create-key DATA
   Hili.Migrator create-key INDEX
   ```
4. The backup file **is the master key**. Move it to offline storage (safe, two copies in separate places,
   dual control if possible) and make sure no copy stays on the server, a share, email, or Git.
5. **Test recovery now:** on another machine (or a test VM with a copy of the DB),
   `Hili.Migrator import-kek --from F:\HILI-KEK-01.backup.txt` must report "Key ring unwrapped successfully".

**Additional web servers / DR / rebuilt server:** `import-kek --from <backup>` on each machine.
Copying the `.kek` file does not work (by design).

**Operational rules:** exclude `C:\ProgramData\Hili\keys` from anything that ships files off the box
(except your normal system-state backup, which is fine — it's only useful on the same machine).
Keep the reader list minimal, and don't run the app pool as an administrator.

**Switching to the HSM later** (no data re-encryption, a few seconds of DB work):
1. Install the HSM client, create the partition, set `HILI_HSM_PIN` as in Setup step 2.
2. In the migrator `App.config`, uncomment the `CryptoTarget:*` block with a **new** label (e.g. `HILI-KEK-02`),
   temporarily set `Crypto:Provider=Pkcs11` + `CryptoTarget` values, run `init-kek` to generate the KEK in the HSM,
   then set `Crypto:*` back to the Dpapi values.
   *(Or generate it with the HSM vendor tool: AES-256, non-extractable, CKA_WRAP/CKA_UNWRAP, label HILI-KEK-02.)*
3. Full DB backup, then `Hili.Migrator rewrap-keys --yes`. This unwraps each `EncKeyRing` row with the DPAPI KEK,
   re-wraps it in the HSM, verifies, updates `KekLabel`, all in one transaction, then proves the ring loads from the HSM alone.
4. Change `Crypto:*` in `Web.config` and `App.config` to the Pkcs11 values (`Crypto:KekLabel=HILI-KEK-02`),
   remove `CryptoTarget:*`, recycle the app pool.
5. Destroy the DPAPI KEK file on every server. Keep the offline backup **only as long as you keep DB backups
   taken before the rewrap** (their `EncKeyRing` is wrapped by HILI-KEK-01); destroy it after they expire.

A new KEK is generated in the HSM rather than importing the old one, because the old key has existed outside
hardware; re-wrapping gets the full benefit of the HSM immediately.

## Migrating existing data & documents (runbook)

| Phase | App state | Steps |
|---|---|---|
| A — online | old app running | Edit `@map` in `02_…sql` to match `encryption-map.json`, run it. Then `Hili.Migrator encrypt-columns`. The triggers clear `_Enc` whenever the old app updates a plaintext column, so the migrator picks those rows up again. Safe to stop/re-run. |
| B — short window | old app stopped | `encrypt-columns` (catch-up) → `verify-columns` (must exit 0) → **full backup** → `03_cutover_drop_plaintext.sql` → deploy the new API. |
| C — online | new API running | `encrypt-files` → `verify-files`. The API serves both legacy (`IsFileEncrypted=0`) and encrypted files during this phase; new uploads are always encrypted. Use `--keep-originals` for a dry run. |

Non-string columns (dates, decimals) are encrypted as invariant-culture strings (`DateTime` → ISO "o");
parse them back the same way in repositories.

## After cutover — plaintext that still exists
- Old full/diff/log backups, replicas, exports, and unallocated pages in data/log files still hold plaintext.
  Set a retention plan for pre-cutover backups; for strict requirements restore into a fresh database.
- Overwrite-then-delete does not guarantee erasure on SSDs, VSS snapshots, or backups of the file share.
- Keep TDE + backup encryption on as well; this scheme protects against DBAs/backup theft, TDE protects the files.

## Key rotation
- **DATA:** `create-key DATA --rotate` → new writes use the new key; old values/files still decrypt
  (old key becomes `DecryptOnly`). Restart the API to load it. Re-encrypting old rows is optional.
- **KEK:** `rewrap-keys` with the new KEK in `CryptoTarget:*` (same procedure as the DPAPI → HSM switch above).
- **INDEX:** requires full re-index (see limitations).

## Security notes
- Anyone authorised to call the API receives plaintext: enable `[Authorize]`, role checks, and audit logs
  for PII reads. Encryption protects at rest, not against a compromised app server.
- Unwrapped data keys live in the app process memory; the HSM session is closed after startup.
- Crypto error details are not returned to clients; log and alert on integrity failures.
